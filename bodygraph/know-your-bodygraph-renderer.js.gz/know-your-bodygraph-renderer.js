/*
 * Know Yourself — MMI-geometry Bodygraph SVG renderer
 * ---------------------------------------------------
 * Geometry source: Stratogos.MMI.Renderer.dll (Maia Mechanics Imaging v1.1.0.0),
 * decompiled to C# (ILSpy) + IL verification (dotnet-ildasm), extracted to
 * mmi-geometry-manifest.json. Every coordinate in the manifest is native MMI
 * chart geometry — this renderer performs NO Human Design mechanics of its own.
 *
 * Input:  chartData = { personalityGates: number[], designGates: number[] }
 *         (produced by the deterministic KY chart engine)
 * Output: SVG string.
 *
 * Rendering conventions (taken from RaveChartRenderer):
 *  - Gate polygons ARE the inter-centre channel segments; activated gates are
 *    filled: Personality = black, Design = red, both = split pattern
 *    (horizontal gates split left/right, vertical gates split top/bottom).
 *  - Centres are painted after gates, covering segment ends.
 *  - Channel "outlines" are thin structural lines (drawn for non-integration
 *    channels only, exactly as in MMI method <channels>).
 *  - Integration channels (10-20, 10-34, 10-57, 20-34, 20-57, 34-57) have no
 *    independent geometry; MMI renders them from six auxiliary shapes
 *    (manifest.integration.auxiliaryShapes, ids 65-70) selected per active
 *    combination — replicated here from decoded method <integration>.
 *
 * KY visual layer (per agreed direction): warm ivory background, deep navy
 * structure, muted gold/copper accents, editorial serif numerals.
 */
(function (global) {
  'use strict';

  var KY = {
    background: '#FAF6EE',
    panel:      '#FDFAF3',
    panelEdge:  '#D8CDB8',
    navy:       '#1E2A44',
    navySoft:   '#3A4A6B',
    ivory:      '#FFFDF7',
    gold:       '#C9A86A',
    goldDeep:   '#A9834B',
    copper:     '#B0653B',
    personality:'#15151A',
    design:     '#A83226',
    channelLine:'#1E2A44',
    font:       "Georgia, 'Times New Roman', serif"
  };

  function fmt(n) { return (Math.round(n * 100) / 100).toString(); }
  function poly(pts) { return pts.map(function (p) { return fmt(p[0]) + ',' + fmt(p[1]); }).join(' '); }

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  /*
   * render(manifest, chartData, opts)
   *   chartData.personalityGates / designGates : arrays of gate numbers (1-64)
   *   opts: { width, title, padding }
   */
  function render(manifest, chartData, opts) {
    opts = opts || {};
    var width = opts.width || 420;
    var m = manifest;
    var bounds = m.coordinateSystem.nativeBounds; // [0,0,336,565]
    var pad = 18;
    var vbX = bounds[0] - pad, vbY = bounds[1] - pad;
    var vbW = bounds[2] - bounds[0] + pad * 2, vbH = bounds[3] - bounds[1] + pad * 2;

    var pers = {}; (chartData.personalityGates || []).forEach(function (g) { pers[g] = true; });
    var des  = {}; (chartData.designGates  || []).forEach(function (g) { des[g] = true; });
    function state(g) {
      var p = !!pers[g], d = !!des[g];
      return p && d ? 'both' : p ? 'personality' : d ? 'design' : null;
    }

    var s = [];
    s.push('<?xml version="1.0" encoding="UTF-8"?>');
    s.push('<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + fmt(vbX) + ' ' + fmt(vbY) + ' ' +
      fmt(vbW) + ' ' + fmt(vbH) + '" width="' + width + '" font-family="' + KY.font + '">');

    // ---- background panel (KY treatment; MMI draws a rounded chart panel) ----
    s.push('<rect x="' + fmt(vbX) + '" y="' + fmt(vbY) + '" width="' + fmt(vbW) + '" height="' + fmt(vbH) +
      '" rx="14" fill="' + KY.panel + '" stroke="' + KY.panelEdge + '" stroke-width="1"/>');

    // defs: split pattern for gates with both activations
    s.push('<defs>');
    s.push('<pattern id="kySplitH" width="2" height="2" patternUnits="userSpaceOnUse">' +
      '<rect width="1" height="2" fill="' + KY.personality + '"/>' +
      '<rect x="1" width="1" height="2" fill="' + KY.design + '"/></pattern>');
    s.push('<pattern id="kySplitV" width="2" height="2" patternUnits="userSpaceOnUse">' +
      '<rect width="2" height="1" fill="' + KY.personality + '"/>' +
      '<rect y="1" width="2" height="1" fill="' + KY.design + '"/></pattern>');
    s.push('</defs>');

    var g, id, gid, i, ch, key;

    // ---- 1. all gate bars in ivory (MMI pre-fills every gate region white) ----
    for (gid = 1; gid <= 64; gid++) {
      g = m.gates[String(gid)];
      s.push('<polygon points="' + poly(g.outline) + '" fill="' + KY.ivory + '" stroke="none"/>');
    }

    // ---- 2. activated gates ----
    for (gid = 1; gid <= 64; gid++) {
      var st = state(gid);
      if (!st) continue;
      g = m.gates[String(gid)];
      var fill;
      if (st === 'personality') fill = KY.personality;
      else if (st === 'design') fill = KY.design;
      else fill = g.isVertical ? 'url(#kySplitV)' : 'url(#kySplitH)';
      s.push('<polygon points="' + poly(g.outline) + '" fill="' + fill + '"/>');
    }

    // ---- 3. integration auxiliary shapes (MMI <integration> combination logic) ----
    var IG = { g10: state(10), g20: state(20), g34: state(34), g57: state(57) };
    function d10() { return IG.g20 && IG.g10 && !IG.g34 && !IG.g57; }
    function d34_10() { return IG.g34 && IG.g10 && !IG.g20 && !IG.g57; }
    function d57_10() { return IG.g57 && IG.g10 && !IG.g20 && !IG.g34; }
    function d34_20() { return IG.g34 && IG.g20 && !IG.g10 && !IG.g57; }
    function d57_34() { return IG.g57 && IG.g34 && !IG.g10 && !IG.g20; }
    var aux = m.integration.auxiliaryShapes;
    function fillAux(aid, fill) {
      var a = aux[String(aid)];
      s.push('<polygon points="' + poly(a.outline) + '" fill="' + fill + '"/>');
    }
    function gateFill(gate) {
      var st = state(gate);
      return st === 'personality' ? KY.personality : st === 'design' ? KY.design :
        KY.navy; // undefined gate contributing to an integration pair: neutral (should not occur in valid charts)
    }
    if (d10())      { fillAux(70, gateFill(10)); fillAux(68, KY.ivory); }
    if (d34_10())   { fillAux(65, gateFill(34)); fillAux(67, gateFill(34)); fillAux(66, gateFill(10)); }
    if (d57_10())   { fillAux(70, gateFill(10)); fillAux(68, gateFill(10)); }
    if (d34_20())   { fillAux(66, gateFill(20)); fillAux(67, gateFill(34)); fillAux(65, gateFill(34)); }
    if (d57_34())   { fillAux(65, gateFill(57)); fillAux(69, KY.ivory); }
    // three defined
    if (IG.g34 && IG.g10 && IG.g57 && !IG.g20) { fillAux(66, gateFill(10)); fillAux(65, gateFill(34)); }
    if (IG.g34 && IG.g20 && IG.g57 && !IG.g10) { fillAux(65, gateFill(34)); fillAux(67, gateFill(57)); }
    if (IG.g34 && IG.g20 && IG.g10 && !IG.g57) { fillAux(65, gateFill(34)); fillAux(67, gateFill(34)); fillAux(66, gateFill(10)); }
    if (IG.g57 && IG.g20 && IG.g10 && !IG.g34) { fillAux(66, gateFill(10)); }
    if (IG.g34 && IG.g20 && IG.g10 && IG.g57)  { fillAux(66, gateFill(10)); fillAux(65, gateFill(34)); }

    // ---- 4. channel structural lines (MMI skips integration channel ids) ----
    for (key in m.channels) {
      ch = m.channels[key];
      if (ch.isIntegration) continue;
      for (i = 0; i < ch.outlines.length; i++) {
        s.push('<line x1="' + fmt(ch.outlines[i][0][0]) + '" y1="' + fmt(ch.outlines[i][0][1]) +
          '" x2="' + fmt(ch.outlines[i][1][0]) + '" y2="' + fmt(ch.outlines[i][1][1]) +
          '" stroke="' + KY.channelLine + '" stroke-width="0.8"/>');
      }
    }
    // integration area web (MMI channel index 36)
    var web = m.integration.areaOutline;
    for (i = 0; i < web.length; i++) {
      s.push('<line x1="' + fmt(web[i][0][0]) + '" y1="' + fmt(web[i][0][1]) +
        '" x2="' + fmt(web[i][1][0]) + '" y2="' + fmt(web[i][1][1]) +
        '" stroke="' + KY.channelLine + '" stroke-width="0.6" stroke-opacity="0.55"/>');
    }

    // ---- 5. centres: white base, then defined fill, then internal lines ----
    var centreNames = Object.keys(m.centres);
    // Definition is canonical engine output. This renderer only maps the
    // supplied channel IDs onto the corresponding geometric centre IDs.
    var engineDefinedChannels = {};
    (chartData.definedChannels || []).forEach(function (channelId) {
      var pair = String(channelId).split('-').map(Number).sort(function (a, b) { return a - b; });
      if (pair.length === 2 && pair.every(function (n) { return n >= 1 && n <= 64; })) {
        engineDefinedChannels[pair.join('-')] = true;
      }
    });
    var definedCentres = {};
    for (key in m.channels) {
      ch = m.channels[key];
      var pairKey = [ch.gateA, ch.gateB].sort(function (a, b) { return a - b; }).join('-');
      if (!engineDefinedChannels[pairKey]) continue;
      definedCentres[m.gates[String(ch.gateA)].centre] = true;
      definedCentres[m.gates[String(ch.gateB)].centre] = true;
    }
    for (i = 0; i < centreNames.length; i++) {
      var c = m.centres[centreNames[i]];
      s.push('<polygon points="' + poly(c.outline) + '" fill="' + KY.ivory + '" stroke="' + KY.navy +
        '" stroke-width="1.4" stroke-linejoin="round"/>');
    }
    for (i = 0; i < centreNames.length; i++) {
      var name = centreNames[i];
      var cc = m.centres[name];
      if (definedCentres[name]) {
        var gradId = 'kyGrad' + name;
        s.push('<defs><linearGradient id="' + gradId + '" x1="0" y1="0" x2="0" y2="1">' +
          '<stop offset="0" stop-color="' + KY.gold + '"/>' +
          '<stop offset="1" stop-color="' + KY.goldDeep + '"/></linearGradient></defs>');
        s.push('<polygon points="' + poly(cc.outline) + '" fill="url(#' + gradId + ')" fill-opacity="0.55"/>');
      }
      for (var j = 0; j < cc.internalLines.length; j++) {
        var ln = cc.internalLines[j];
        s.push('<line x1="' + fmt(ln[0][0]) + '" y1="' + fmt(ln[0][1]) + '" x2="' + fmt(ln[1][0]) +
          '" y2="' + fmt(ln[1][1]) + '" stroke="' + KY.navy + '" stroke-width="0.8" stroke-opacity="0.85"/>');
      }
    }

    // ---- 6. gate numbers ----
    for (gid = 1; gid <= 64; gid++) {
      var lp = m.gates[String(gid)].labelPosition;
      var active = state(gid);
      if (active) {
        s.push('<circle cx="' + fmt(lp[0] + 3.5) + '" cy="' + fmt(lp[1] + 4) + '" r="6.2" fill="' + KY.gold +
          '" fill-opacity="0.9"/>');
      }
      s.push('<text x="' + fmt(lp[0]) + '" y="' + fmt(lp[1] + 8) + '" font-size="8.5" font-weight="bold" fill="' +
        (active ? KY.navy : KY.navySoft) + '">' + gid + '</text>');
    }

    // fully defined channel markers: subtle copper ring on the pair's midpoints is
    // intentionally omitted — MMI shows definition through continuous filled segments.

    if (opts.title) {
      s.push('<text x="' + fmt(vbX + vbW / 2) + '" y="' + fmt(vbY + 12) + '" text-anchor="middle" font-size="9" font-style="italic" fill="' + KY.navySoft + '">' + esc(opts.title) + '</text>');
    }
    s.push('</svg>');
    return s.join('\n');
  }

  /* Validation helpers (structural checks, no mechanics) */
  function validate(manifest, chartData) {
    var issues = [];
    var centreCount = Object.keys(manifest.centres).length;
    var gateCount = Object.keys(manifest.gates).length;
    var chCount = Object.keys(manifest.channels).length;
    if (centreCount !== 9) issues.push('centre count ' + centreCount + ' != 9');
    if (gateCount !== 64) issues.push('gate count ' + gateCount + ' != 64');
    if (chCount !== 36) issues.push('channel count ' + chCount + ' != 36');
    var usage = {}; // gate -> channel count (integration gates 10/20/34/57 belong to 3 channels each)
    for (var k in manifest.channels) {
      var ch = manifest.channels[k];
      usage[ch.gateA] = (usage[ch.gateA] || 0) + 1;
      usage[ch.gateB] = (usage[ch.gateB] || 0) + 1;
    }
    var INTEGRATION_GATES = { 10: 1, 20: 1, 34: 1, 57: 1 };
    for (var ug in usage) {
      var expected = INTEGRATION_GATES[ug] ? 3 : 1;
      if (usage[ug] !== expected) issues.push('gate ' + ug + ' appears in ' + usage[ug] + ' channels, expected ' + expected);
    }
    var gateSeen = {};
    for (var c in manifest.centres) {
      manifest.centres[c].gates = manifest.centres[c].gates || [];
    }
    for (var g in manifest.gates) {
      var centre = manifest.gates[g].centre;
      if (!manifest.centres[centre]) issues.push('gate ' + g + ' unknown centre ' + centre);
      gateSeen[g] = true;
    }
    for (var gd = 1; gd <= 64; gd++) if (!gateSeen[gd]) issues.push('missing gate ' + gd);
    ['personalityGates', 'designGates'].forEach(function (key) {
      (chartData[key] || []).forEach(function (g) {
        if (g < 1 || g > 64) issues.push(key + ' gate out of range: ' + g);
      });
    });
    return { ok: issues.length === 0, issues: issues };
  }

  var api = { render: render, validate: validate, palette: KY };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else global.KYBodygraphRenderer = api;
})(typeof window !== 'undefined' ? window : this);
